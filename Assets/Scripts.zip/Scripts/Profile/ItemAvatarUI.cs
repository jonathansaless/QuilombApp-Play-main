using UnityEngine;

// Este script serve apenas como um "contêiner" para guardar o ID do avatar
public class ItemAvatarUI : MonoBehaviour
{
    public int avatarId;
}