using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using TMPro;

public class PuzzleManager : MonoBehaviour
{
    [Header("Identificação do Nível")]
    [Tooltip("ID único para este nível. Ex: 'puzzle_animais_1'")]
    public string idDoNivel = "puzzle_nivel_1";

    [Header("Configuração do Puzzle")]
    public PuzzleData puzzleAtual; // Agora contém a variável movimentosMaximos

    [Header("Referências da UI do Puzzle")]
    public Transform gridPanel;
    public Transform pecasEmbaralhadasPanel;
    public GameObject pecaPrefab;
    public GameObject slotVazioPrefab;
    public Image imagemReferencia;
    public TextMeshProUGUI textoMovimentos;

    [Header("Referências de Drag & Drop")]
    public Canvas canvasPrincipal;

    #region Variáveis de Jogo e Estado

    private int movimentos = 0;
    private float tempoInicioPuzzle;
    private bool jogoAtivo = false;

    [Header("Referências da UI - HUD")]
    public TextMeshProUGUI textoCronometro;
    public TextMeshProUGUI textoMoedas;
    public TextMeshProUGUI textoVidas;

    [Header("Painéis de Confirmação")]
    public GameObject painelConfirmacaoSair;
    public GameObject painelConfirmacaoReiniciar;

    private bool jogoPausado = false;
    private float tempoPausadoAcumulado = 0f;
    private float tempoInicioPausa;

    #endregion

    #region Ciclo de Vida da Unity

    void Start()
    {
        if (GameDataHolder.NivelParaCarregar != null)
        {
            // O tipo de 'NivelParaCarregar' precisa ser convertido para o tipo de dado correto
            
            puzzleAtual = (PuzzleData)GameDataHolder.NivelParaCarregar;
            
            // Atualiza o idDoNivel para o que foi carregado
            idDoNivel = GameDataHolder.NivelParaCarregar.idDoNivel;
            
            // Limpa o transportador para a próxima vez
            // GameDataHolder.NivelParaCarregar = null;
        }
        else
        {
            Debug.LogWarning("Nenhum nível para carregar via GameDataHolder. Usando o nível definido no Inspector (Modo de Teste).");
        }

        if (PlayerDataManager.Instance == null || PlayerDataManager.Instance.Dados == null)
        {
            SceneManager.LoadScene("CenaLogin");
            return;
        }

        AtualizarHUD();

        InicializarPuzzle();
        ConfigurarPuzzle();
    }

    void Update()
    {
        if (jogoAtivo && !jogoPausado)
        {
            float tempoDecorrido = (Time.time - tempoInicioPuzzle) - tempoPausadoAcumulado;
            if (tempoDecorrido < 0) tempoDecorrido = 0;
            int minutos = (int)tempoDecorrido / 60;
            int segundos = (int)tempoDecorrido % 60;
            textoCronometro.text = string.Format("{0:00}:{1:00}", minutos, segundos);
        }
    }

    #endregion

    #region Lógica Principal do Puzzle

    void InicializarPuzzle()
    {
        movimentos = 0;
        // Lê o número máximo de movimentos diretamente do ScriptableObject (nível atual)
        textoMovimentos.text = $"Nº de Movimentos: {movimentos} / {puzzleAtual.NumeroMaxMovimentos}";
        jogoAtivo = true;
        tempoInicioPuzzle = Time.time;
        tempoPausadoAcumulado = 0f;
    }

    void ConfigurarPuzzle()
    {
        imagemReferencia.sprite = puzzleAtual.imagemReferencia;
        
        foreach (Transform child in gridPanel) { Destroy(child.gameObject); }
        foreach (Transform child in pecasEmbaralhadasPanel) { Destroy(child.gameObject); }

        List<GameObject> slotsParaEmbaralhar = new List<GameObject>();
        for (int i = 0; i < puzzleAtual.pecasDoPuzzle.Count; i++)
        {
            GameObject slotObj = Instantiate(slotVazioPrefab, gridPanel);
            slotObj.GetComponent<SlotDePeca>().manager = this;
            slotObj.GetComponent<SlotDePeca>().idDoSlot = i;
        }
        for (int i = 0; i < puzzleAtual.pecasDoPuzzle.Count; i++)
        {
            GameObject slotPecaObj = Instantiate(slotVazioPrefab, pecasEmbaralhadasPanel);
            slotPecaObj.GetComponent<SlotDePeca>().manager = this;
            slotPecaObj.GetComponent<SlotDePeca>().idDoSlot = -1;
            slotsParaEmbaralhar.Add(slotPecaObj);
            GameObject pecaObj = Instantiate(pecaPrefab, slotPecaObj.transform);
            pecaObj.GetComponent<Image>().sprite = puzzleAtual.pecasDoPuzzle[i];
            pecaObj.GetComponent<PecaArrastavel>().idDaPeca = i;
        }
        for (int i = 0; i < slotsParaEmbaralhar.Count; i++)
        {
            int randomIndex = Random.Range(i, slotsParaEmbaralhar.Count);
            slotsParaEmbaralhar[i].transform.SetSiblingIndex(randomIndex);
        }
        jogoAtivo = true;
    }

    public void PecaMovida(GameObject peca, SlotDePeca novoSlot)
    {
        if (!jogoAtivo) return;

        PecaArrastavel pecaArrastavel = peca.GetComponent<PecaArrastavel>();

        if (novoSlot.transform != pecaArrastavel.paiOriginal && novoSlot.idDoSlot != -1)
        {
            movimentos++;
            textoMovimentos.text = $"Nº de Movimentos: {movimentos} / {puzzleAtual.NumeroMaxMovimentos}";
        }

        VerificarCondicaoDeFimDeJogo();
    }

    void VerificarCondicaoDeFimDeJogo()
    {
        bool vitoria = true;
        if (gridPanel.childCount < puzzleAtual.pecasDoPuzzle.Count)
        {
             vitoria = false;
        }
        else
        {
            for (int i = 0; i < gridPanel.childCount; i++)
            {
                Transform slot = gridPanel.GetChild(i);
                if (slot.childCount == 0 || slot.GetChild(0).GetComponent<PecaArrastavel>().idDaPeca != i)
                {
                    vitoria = false;
                    break;
                }
            }
        }
        
        if (vitoria)
        {
            Debug.Log("VOCÊ VENCEU!");
            FimDeJogo(true); // Informa que foi uma vitória
            return;
        }

        // Verifica a derrota usando o valor do nível atual
        if (movimentos >= puzzleAtual.NumeroMaxMovimentos)
        {
            Debug.Log("VOCÊ PERDEU! Limite de movimentos atingido.");
            FimDeJogo(false); // Informa que foi uma derrota
        }
    }

    void FimDeJogo(bool vitoria)
    {
        if (!jogoAtivo) return;
        jogoAtivo = false;

        float tempoTotal = (Time.time - tempoInicioPuzzle) - tempoPausadoAcumulado;

        // Passa as informações para as próximas cenas
        PlayerPrefs.SetString("idDoNivelFinal", idDoNivel);
        PlayerPrefs.SetFloat("TempoFinal", tempoTotal);
        PlayerPrefs.SetInt("MovimentosFinal", movimentos);
        PlayerPrefs.SetString("ResultadoFinal", vitoria ? "vitoria" : "derrota");
        PlayerPrefs.SetInt("MovimentosMaximosDoNivel", puzzleAtual.NumeroMaxMovimentos);
        
        if (vitoria)
        {
            // Se venceu, passa os dados do nível e vai para a explicação
            GameDataHolder.NivelParaCarregar = puzzleAtual;
            // Guarda o nome da cena de feedback que virá DEPOIS da explicação
            PlayerPrefs.SetString("CenaFeedbackDestino", "CenaFeedbackQuebraCabeca");
            SceneManager.LoadScene("CenaExplicacao");
        }
        else
        {
            // Se perdeu, vai direto para o feedback, como antes
            SceneManager.LoadScene("CenaFeedbackQuebraCabeca");
        }
        
        PlayerPrefs.Save();
    }

    #endregion

    #region Funções de UI
    
    void AtualizarHUD()
    {
        if (PlayerDataManager.Instance != null && PlayerDataManager.Instance.Dados != null)
        {
            textoMoedas.text = PlayerDataManager.Instance.Dados.Moedas.ToString();
            textoVidas.text = PlayerDataManager.Instance.Dados.Vidas.ToString();
        }
    }
    public void MostrarConfirmacaoSair()
    {
        if (!jogoAtivo) return;
        jogoPausado = true;
        tempoInicioPausa = Time.time;
        painelConfirmacaoSair.SetActive(true);
    }
    public void MostrarConfirmacaoReiniciar()
    {
        if (!jogoAtivo) return;
        jogoPausado = true;
        tempoInicioPausa = Time.time;
        painelConfirmacaoReiniciar.SetActive(true);
    }
    public void FecharPainelConfirmacao()
    {
        if (jogoPausado)
        {
            tempoPausadoAcumulado += Time.time - tempoInicioPausa;
        }
        jogoPausado = false;
        if (painelConfirmacaoSair != null) painelConfirmacaoSair.SetActive(false);
        if (painelConfirmacaoReiniciar != null) painelConfirmacaoReiniciar.SetActive(false);
    }
    public void ConfirmarSair()
    {
        jogoPausado = false;
        SceneManager.LoadScene("CenaMenu");
    }
    public void ConfirmarReiniciar()
    {
        jogoPausado = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    #endregion
    
    #region Funções de Teste e Debug
    
    public void VitoriaParaTeste()
    {
        if (!jogoAtivo) return;
        Debug.LogWarning("!!! VITÓRIA FORÇADA PARA FINS DE TESTE !!!");
        FimDeJogo(true); // Chama o fim de jogo com resultado de vitória
    }
    
    #endregion
}