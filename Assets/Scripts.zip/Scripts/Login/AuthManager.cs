using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using Firebase;
using Firebase.Auth;
using Firebase.Firestore;
using System.Threading.Tasks;
using System.Collections.Generic;

public class AuthManager : MonoBehaviour
{
    [Header("Configurações")]
    public float tempoMinimoCarregamento = 5.0f; // Duração mínima em segundos

    [Header("Firebase")]
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseUser user;

    [Header("Painéis")]
    public GameObject painelLogin;
    public GameObject painelRegistro;
    public GameObject painelVisitante;
    public GameObject painelCarregamento;

    [Header("UI Login")]
    public TMP_InputField emailLoginInput;
    public TMP_InputField senhaLoginInput;
    public TextMeshProUGUI textoFeedbackLogin;

    [Header("UI Registro")]
    public TMP_InputField emailRegistroInput;
    public TMP_InputField apelidoRegistroInput;
    public TMP_InputField idadeRegistroInput;
    public TMP_InputField senhaRegistroInput;
    public TextMeshProUGUI textoFeedbackRegistro;

    [Header("UI Visitante")]
    public TMP_InputField apelidoVisitanteInput;
    public TMP_InputField idadeVisitanteInput;
    public TextMeshProUGUI textoFeedbackVisitante;

    void Start()
    {
        // Garante que os painéis comecem em um estado conhecido
        MostrarPainelLogin();
        if (painelCarregamento != null) painelCarregamento.SetActive(false);

        // Apenas inicializa as variáveis do Firebase
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWith(task => {
            var dependencyStatus = task.Result;
            if (dependencyStatus == DependencyStatus.Available)
            {
                auth = FirebaseAuth.DefaultInstance;
                db = FirebaseFirestore.DefaultInstance;
            }
            else
            {
                Debug.LogError($"Erro nas dependências do Firebase: {dependencyStatus}");
            }
        });
    }

    #region Funções de UI
    public void MostrarPainelLogin()
    {
        painelLogin.SetActive(true);
        painelRegistro.SetActive(false);
        painelVisitante.SetActive(false);
        if(painelCarregamento != null) painelCarregamento.SetActive(false);
    }

    public void MostrarPainelRegistro()
    {
        painelLogin.SetActive(false);
        painelRegistro.SetActive(true);
        painelVisitante.SetActive(false);
        if(painelCarregamento != null) painelCarregamento.SetActive(false);
    }

    public void MostrarPainelVisitante()
    {
        painelLogin.SetActive(false);
        painelRegistro.SetActive(false);
        painelVisitante.SetActive(true);
        if(painelCarregamento != null) painelCarregamento.SetActive(false);
    }
    
    private void MostrarPainelCarregamento()
    {
        painelLogin.SetActive(false);
        painelRegistro.SetActive(false);
        painelVisitante.SetActive(false);
        if(painelCarregamento != null) painelCarregamento.SetActive(true);
    }
    #endregion

    #region Funções de Autenticação
    public async void Registrar()
    {
        if (string.IsNullOrEmpty(emailRegistroInput.text) || string.IsNullOrEmpty(senhaRegistroInput.text) || string.IsNullOrEmpty(apelidoRegistroInput.text))
        {
            textoFeedbackRegistro.text = "Por favor, preencha todos os campos.";
            return;
        }

        textoFeedbackRegistro.text = "Registrando...";
        MostrarPainelCarregamento();

        try
        {
            var registerTask = await auth.CreateUserWithEmailAndPasswordAsync(emailRegistroInput.text, senhaRegistroInput.text);
            user = registerTask.User;

            UserProfile profile = new UserProfile { DisplayName = apelidoRegistroInput.text };
            await user.UpdateUserProfileAsync(profile);

            Task creationTask = CriarDadosIniciaisDoJogador(user.UserId, apelidoRegistroInput.text, int.Parse(idadeRegistroInput.text));
            Task delayTask = Task.Delay((int)(tempoMinimoCarregamento * 1000));
            await Task.WhenAll(creationTask, delayTask);

            await PlayerDataManager.Instance.CarregarDadosDoFirebase();
            SceneManager.LoadScene("CenaMenu");
        }
        catch (FirebaseException ex)
        {
            MostrarPainelRegistro();
            textoFeedbackRegistro.text = ObterMensagemDeErro(ex);
        }
    }

    public async void FazerLogin()
    {
        if (string.IsNullOrEmpty(emailLoginInput.text) || string.IsNullOrEmpty(senhaLoginInput.text))
        {
            textoFeedbackLogin.text = "Preencha e-mail e senha.";
            return;
        }

        textoFeedbackLogin.text = "Entrando...";
        MostrarPainelCarregamento();

        try
        {
            var loginTask = await auth.SignInWithEmailAndPasswordAsync(emailLoginInput.text, senhaLoginInput.text);
            user = loginTask.User;

            Task loadingTask = PlayerDataManager.Instance.CarregarDadosDoFirebase();
            Task delayTask = Task.Delay((int)(tempoMinimoCarregamento * 1000));
            await Task.WhenAll(loadingTask, delayTask);
            
            SceneManager.LoadScene("CenaMenu");
        }
        catch (FirebaseException ex)
        {
            MostrarPainelLogin();
            textoFeedbackLogin.text = ObterMensagemDeErro(ex);
        }
    }

    public async void LoginComoVisitante()
    {
        if (string.IsNullOrEmpty(apelidoVisitanteInput.text))
        {
            textoFeedbackVisitante.text = "Por favor, insira um apelido.";
            return;
        }

        textoFeedbackVisitante.text = "Entrando...";
        MostrarPainelCarregamento();
        
        try
        {
            var loginTask = await auth.SignInAnonymouslyAsync();
            user = loginTask.User;

            UserProfile profile = new UserProfile { DisplayName = apelidoVisitanteInput.text };
            await user.UpdateUserProfileAsync(profile);
            
            int.TryParse(idadeVisitanteInput.text, out int idade); // Converte idade de forma segura

            Task creationTask = CriarDadosIniciaisDoJogador(user.UserId, apelidoVisitanteInput.text, idade);
            Task delayTask = Task.Delay((int)(tempoMinimoCarregamento * 1000));
            await Task.WhenAll(creationTask, delayTask);

            await PlayerDataManager.Instance.CarregarDadosDoFirebase();
            SceneManager.LoadScene("CenaMenu");
        }
        catch (FirebaseException ex)
        {
            MostrarPainelVisitante();
            textoFeedbackVisitante.text = $"Erro: {ex.Message}";
        }
    }
    #endregion

    private async Task CriarDadosIniciaisDoJogador(string userId, string apelido, int idade)
    {
        DocumentReference docRef = db.Collection("jogadores").Document(userId);
        Dictionary<string, object> dadosIniciais = new Dictionary<string, object>
        {
            { "Apelido", apelido },
            { "Idade", idade },
            { "Vidas", 5 },
            { "Moedas", 0 },
            { "PontuacaoMaximaTotal", 0 },
            { "QuantidadeDica", 3 },
            { "Quantidade5050", 3 },
            { "QuantidadeDuasChances", 3 },
            { "AvataresPossuidos", new List<int> { 0 } },
            { "AvatarEquipadoID", 0 }
        };
        await docRef.SetAsync(dadosIniciais);
    }

    // Função auxiliar para traduzir os erros mais comuns do Firebase
    private string ObterMensagemDeErro(FirebaseException ex)
    {
        AuthError errorCode = (AuthError)ex.ErrorCode;
        switch (errorCode)
        {
            case AuthError.WrongPassword:
                return "Senha incorreta.";
            case AuthError.UserNotFound:
                return "Usuário não encontrado.";
            case AuthError.InvalidEmail:
                return "O e-mail fornecido é inválido.";
            case AuthError.EmailAlreadyInUse:
                return "Este e-mail já está em uso.";
            case AuthError.WeakPassword:
                return "A senha precisa ter pelo menos 6 caracteres.";
            default:
                return "Ocorreu um erro. Tente novamente.";
        }
    }
}