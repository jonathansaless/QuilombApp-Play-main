using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class ExplanationManager : MonoBehaviour
{
    [Header("Configurações de Paginação")]
    [Tooltip("Número máximo de caracteres por página, incluindo espaços.")]
    public int maxCaracteresPorPagina = 115;

    [Header("Referências da UI")]
    public Image imagemPrincipal;
    public TextMeshProUGUI textoExplicacao;
    public TextMeshProUGUI textoContadorPaginas;
    public TextMeshProUGUI textoTitulo;
    public TextMeshProUGUI textoFonte;
    public Button botaoProximaPagina;
    public Button botaoRetornar;

    private List<string> paginas;
    private int paginaAtual = 0;
    private string cenaFeedbackDestino;

    void Start()
    {
        NivelDataBase nivelData = GameDataHolder.NivelParaCarregar;
        
        if (nivelData == null)
        {
            Debug.LogError("Nenhum dado de nível encontrado! Voltando ao menu.");
            SceneManager.LoadScene("CenaMenu");
            return;
        }

        cenaFeedbackDestino = PlayerPrefs.GetString("CenaFeedbackDestino");

        Sprite spritePrincipal = null;
        string textoCompleto = "";
        string titulo = "";
        string fonte = ""; // Variável local para guardar a fonte

        // Lógica de verificação de tipo para pegar os dados corretos
        if (nivelData is PuzzleData puzzleData)
        {
            spritePrincipal = puzzleData.imagemPrincipal;
            textoCompleto = puzzleData.textoDaExplicacao;
            titulo = puzzleData.titulo;
            fonte = puzzleData.fonteExplicacao; // Pega a fonte do PuzzleData
        }
        else if (nivelData is WordGameData wordGameData)
        {
            spritePrincipal = wordGameData.imagemPrincipal;
            textoCompleto = wordGameData.textoDaExplicacao;
            titulo = wordGameData.titulo;
            fonte = wordGameData.fonteExplicacao; // Pega a fonte do WordGameData
        }
        else
        {
            Debug.LogWarning($"O nível '{nivelData.idDoNivel}' não tem conteúdo de explicação. Pulando para o feedback.");
            IrParaFeedback();
            return;
        }

        paginas = PaginarTexto(textoCompleto, maxCaracteresPorPagina);

        // Preenche as informações na tela
        imagemPrincipal.sprite = spritePrincipal;
        textoTitulo.text = string.IsNullOrEmpty(titulo) ? "" : titulo.ToUpper();

        if (textoFonte != null)
        {
            // Verifica se a string da fonte não é nula ou vazia
            if (!string.IsNullOrEmpty(fonte))
            {
                // Se houver texto, ativa o objeto e formata a string
                textoFonte.gameObject.SetActive(true);
                textoFonte.text = $"Fonte: {fonte}";
            }
            else
            {
                // Se não houver texto, desativa o objeto
                textoFonte.gameObject.SetActive(false);
            }
        }

        MostrarPagina(0);
    }

    void MostrarPagina(int index)
    {
        paginaAtual = index;
        textoExplicacao.text = paginas[paginaAtual];
        textoContadorPaginas.text = $"{paginaAtual + 1}/{paginas.Count}";

        botaoProximaPagina.gameObject.SetActive(paginaAtual < paginas.Count - 1);
        botaoRetornar.gameObject.SetActive(paginaAtual >= paginas.Count - 1);
    }

    // --- NOVA FUNÇÃO DE PAGINAÇÃO AUTOMÁTICA ---
    private List<string> PaginarTexto(string textoCompleto, int maxCaracteres)
    {
        var paginasResultantes = new List<string>();
        if (string.IsNullOrEmpty(textoCompleto))
        {
            paginasResultantes.Add("Nenhuma explicação encontrada para este nível.");
            return paginasResultantes;
        }

        string textoRestante = textoCompleto;
        while (textoRestante.Length > 0)
        {
            if (textoRestante.Length <= maxCaracteres)
            {
                paginasResultantes.Add(textoRestante);
                break;
            }

            // Pega um pedaço do texto e procura o último espaço
            string pedaco = textoRestante.Substring(0, maxCaracteres);
            int ultimoEspaco = pedaco.LastIndexOf(' ');

            // Se encontrou um espaço, corta ali. Senão, corta na marra no limite de caracteres.
            int pontoDeCorte = (ultimoEspaco > 0) ? ultimoEspaco : maxCaracteres;

            paginasResultantes.Add(textoRestante.Substring(0, pontoDeCorte));
            textoRestante = textoRestante.Substring(pontoDeCorte).TrimStart();
        }

        return paginasResultantes;
    }

    public void ProximaPagina()
    {
        if (paginaAtual < paginas.Count - 1)
        {
            MostrarPagina(paginaAtual + 1);
        }
    }

    public void IrParaFeedback()
    {
        GameDataHolder.NivelParaCarregar = null;
        PlayerPrefs.DeleteKey("CenaFeedbackDestino");

        if (!string.IsNullOrEmpty(cenaFeedbackDestino))
        {
            SceneManager.LoadScene(cenaFeedbackDestino);
        }
        else
        {
            Debug.LogError("Nome da cena de feedback não encontrado! Voltando ao menu.");
            SceneManager.LoadScene("CenaMenu");
        }
    }
}