using UnityEngine;

public abstract class NivelDataBase : ScriptableObject
{
    [Header("Identificação do Nível")]
    public string idDoNivel;
}