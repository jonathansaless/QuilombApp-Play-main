using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine.SceneManagement;
using System.Text;

public class WordGameManager : MonoBehaviour
{
    [Header("Identificação do Nível")]
    [Tooltip("ID único para este nível. Ex: 'palavras_cultura_1'")]
    public string idDoNivel = "palavras_nivel_1";

    [Header("Configuração do Nível")]
    public WordGameData nivelAtual;
    // public int movimentosMaximos = 30;

    [Header("Referências da UI - Jogo")]
    public TextMeshProUGUI textoPerguntaAvatar;
    public Image imagemDica;
    public Transform painelSlotsResposta;
    public Transform painelLetrasDisponiveis;

    [Header("Prefabs")]
    public GameObject slotLetraPrefab;
    public GameObject slotRespostaPrefab;
    public GameObject letraPrefab;

    [Header("Referências da UI - HUD")]
    public TextMeshProUGUI textoMovimentos;
    public TextMeshProUGUI textoCronometro;
    public TextMeshProUGUI textoMoedas;
    public TextMeshProUGUI textoVidas;
    
    [Header("Painéis de Confirmação")]
    public GameObject painelConfirmacaoSair;
    public GameObject painelConfirmacaoReiniciar;

    // Variáveis de estado do jogo
    private int movimentos = 0;
    private float tempoInicioJogo;
    private bool jogoAtivo = false;

    private bool jogoPausado = false;
    private float tempoPausadoAcumulado = 0f;
    private float tempoInicioPausa;

    #region Ciclo de Vida da Unity

    void Start()
    {
        if (GameDataHolder.NivelParaCarregar != null)
        {
            // Exemplo para WordGameManager:
            nivelAtual = (WordGameData)GameDataHolder.NivelParaCarregar;

            // Atualiza o idDoNivel para o que foi carregado
            idDoNivel = GameDataHolder.NivelParaCarregar.idDoNivel;
            
            // // Limpa o transportador para a próxima vez
            // GameDataHolder.NivelParaCarregar = null;
        }
        else
        {
            Debug.LogWarning("Nenhum nível para carregar via GameDataHolder. Usando o nível definido no Inspector (Modo de Teste).");
        }

        if (PlayerDataManager.Instance == null || PlayerDataManager.Instance.Dados == null)
        {
            Debug.LogError("PlayerDataManager não encontrado! Voltando para a cena de Login.");
            SceneManager.LoadScene("CenaLogin");
            return;
        }

        // // Verifica se todas as referências essenciais foram ligadas no Inspector
        // if (!VerificarReferencias())
        // {
        //     // Se uma referência estiver faltando, desativa o jogo para evitar mais erros.
        //     this.enabled = false;
        //     return;
        // }
        
        AtualizarHUD();

        InicializarJogo();
        ConfigurarNivel();
    }

    void Update()
    {
        // O cronômetro agora só avança se o jogo estiver ativo E não pausado
        if (jogoAtivo && !jogoPausado)
        {
            float tempoDecorrido = (Time.time - tempoInicioJogo) - tempoPausadoAcumulado;
            int minutos = (int)tempoDecorrido / 60;
            int segundos = (int)tempoDecorrido % 60;
            textoCronometro.text = string.Format("{0:00}:{1:00}", minutos, segundos);
        }
    }

    #endregion

    #region Configuração do Jogo

    void InicializarJogo()
    {
        movimentos = 0;
        textoMovimentos.text = $"Nº de Movimentos: {movimentos} / {nivelAtual.NumeroMaxMovimentos}";
        jogoAtivo = true;
        tempoInicioJogo = Time.time;

        jogoPausado = false;
        tempoPausadoAcumulado = 0f;
        tempoInicioPausa = 0f;
    }

    void ConfigurarNivel()
    {
        // Limpa os painéis de qualquer configuração anterior
        foreach (Transform child in painelSlotsResposta) { Destroy(child.gameObject); }
        foreach (Transform child in painelLetrasDisponiveis) { Destroy(child.gameObject); }

        // Carrega as informações do nível
        textoPerguntaAvatar.text = nivelAtual.textoDaPergunta;
        imagemDica.sprite = nivelAtual.imagemDeDica;

        // Cria os slots de resposta vazios
        for (int i = 0; i < nivelAtual.respostaCorreta.Length; i++)
        {
            GameObject slotObj = Instantiate(slotRespostaPrefab, painelSlotsResposta);
            slotObj.GetComponent<SlotDeLetra>().manager = this;
        }

        // Embaralha as letras disponíveis
        var letras = nivelAtual.letrasParaEmbaralhar.ToList();
        System.Random rng = new System.Random();
        letras = letras.OrderBy(a => rng.Next()).ToList();

        // Cria os slots e as letras arrastáveis
        foreach (char letraChar in letras)
        {
            GameObject slotOrigem = Instantiate(slotLetraPrefab, painelLetrasDisponiveis);
            slotOrigem.GetComponent<SlotDeLetra>().manager = this;

            GameObject letraObj = Instantiate(letraPrefab, slotOrigem.transform);
            letraObj.GetComponentInChildren<TextMeshProUGUI>().text = letraChar.ToString();
            letraObj.GetComponent<LetraArrastavel>().letra = letraChar;
        }
    }

    #endregion

    #region Lógica Principal do Jogo

    public void LetraMovida()
    {
        if (!jogoAtivo) return;

        movimentos++;
        textoMovimentos.text = $"Nº de Movimentos: {movimentos} / {nivelAtual.NumeroMaxMovimentos}";

        VerificarCondicaoDeFimDeJogo();
    }

    void VerificarCondicaoDeFimDeJogo()
    {
        // Verifica derrota por excesso de movimentos
        if (movimentos >= nivelAtual.NumeroMaxMovimentos)
        {
            Debug.Log("FIM DE JOGO: Limite de movimentos atingido.");
            FimDeJogo(false);
            return;
        }

        // Verifica se todos os slots de resposta estão preenchidos
        foreach (Transform slot in painelSlotsResposta)
        {
            if (slot.childCount == 0)
            {
                return; // Jogo continua, pois faltam letras
            }
        }

        // Se todos os slots estão preenchidos, constrói a palavra formada
        StringBuilder palavraFormadaBuilder = new StringBuilder();
        foreach (Transform slot in painelSlotsResposta)
        {
            palavraFormadaBuilder.Append(slot.GetChild(0).GetComponent<LetraArrastavel>().letra);
        }

        // --- MUDANÇAS IMPORTANTES AQUI ---

        // 1. Convertemos para string e removemos espaços em branco do início e do fim
        string palavraFormada = palavraFormadaBuilder.ToString().Trim();
        string respostaCorreta = nivelAtual.respostaCorreta.Trim();

        // 2. Adicionamos Debug.Log para ver exatamente o que está sendo comparado no Console
        Debug.Log($"Comparando: Palavra Formada='{palavraFormada}' | Resposta Correta='{respostaCorreta}'");

        // 3. A comparação continua a mesma, mas agora com as strings limpas
        if (palavraFormada.Equals(respostaCorreta, System.StringComparison.InvariantCultureIgnoreCase))
        {
            Debug.Log("VERIFICAÇÃO CORRETA! Palavra bateu. Chamando FimDeJogo com vitória.");
            FimDeJogo(true);
        }
        else
        {
            // Esta mensagem é útil para saber que o jogo verificou, mas a palavra estava errada
            Debug.Log("Palavra formada está incorreta. O jogo continua.");
        }
    }

    void FimDeJogo(bool vitoria)
    {
        if (!jogoAtivo) return;
        jogoAtivo = false;
        
        float tempoTotal = (Time.time - tempoInicioJogo) - tempoPausadoAcumulado;

        PlayerPrefs.SetString("idDoNivelFinal", idDoNivel);
        PlayerPrefs.SetInt("MovimentosFinal", movimentos);
        PlayerPrefs.SetFloat("TempoFinal", tempoTotal);
        PlayerPrefs.SetString("ResultadoFinal", vitoria ? "vitoria" : "derrota");
        PlayerPrefs.SetInt("MovimentosMaximosDoNivel", nivelAtual.NumeroMaxMovimentos);

        if (vitoria)
        {
            // Se venceu, passa os dados do nível e vai para a explicação
            GameDataHolder.NivelParaCarregar = nivelAtual;
            // Guarda o nome da cena de feedback que virá DEPOIS da explicação
            PlayerPrefs.SetString("CenaFeedbackDestino", "CenaFeedbackJogoDePalavras");
            SceneManager.LoadScene("CenaExplicacao");
        }
        else
        {
            // Se perdeu, vai direto para o feedback, como antes
            SceneManager.LoadScene("CenaFeedbackJogoDePalavras");
        }

        PlayerPrefs.Save();
    }

    #endregion

    #region Funções de UI e Auxiliares

    void AtualizarHUD()
    {
        if (textoMoedas != null) textoMoedas.text = PlayerDataManager.Instance.Dados.Moedas.ToString();
        if (textoVidas != null) textoVidas.text = PlayerDataManager.Instance.Dados.Vidas.ToString();
    }

    public void MostrarConfirmacaoSair()
    {
        if (!jogoAtivo) return;
        jogoPausado = true;
        tempoInicioPausa = Time.time;
        if (painelConfirmacaoSair != null) painelConfirmacaoSair.SetActive(true);
    }

    public void MostrarConfirmacaoReiniciar()
    {
        if (!jogoAtivo) return;
        jogoPausado = true;
        tempoInicioPausa = Time.time;
        if (painelConfirmacaoReiniciar != null) painelConfirmacaoReiniciar.SetActive(true);
    }

    // Fecha todos os painéis de confirmação (chamada pelo botão "Não" ou "Cancelar")
    public void FecharPainelConfirmacao()
    {
        if (jogoPausado)
        {
            tempoPausadoAcumulado += Time.time - tempoInicioPausa;
        }
        jogoPausado = false;
        if (painelConfirmacaoSair != null) painelConfirmacaoSair.SetActive(false);
        if (painelConfirmacaoReiniciar != null) painelConfirmacaoReiniciar.SetActive(false);
    }

    // Funções de confirmação (chamadas pelo botão "Sim")
    public void ConfirmarSair()
    {
        jogoPausado = false; // Despausa o jogo para evitar problemas de estado
        SceneManager.LoadScene("CenaMenu");
    }

    public void ConfirmarReiniciar()
    {
        jogoPausado = false; // Despausa o jogo para evitar problemas de estado
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    #endregion

    
}