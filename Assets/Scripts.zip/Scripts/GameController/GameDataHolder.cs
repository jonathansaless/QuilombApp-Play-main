public static class GameDataHolder
{
    public static NivelDataBase NivelParaCarregar;
    public static ModoDeJogoData ModoDeJogoParaCarregar;
}