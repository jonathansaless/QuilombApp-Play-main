using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class FeedbackManager : MonoBehaviour
{
    [Header("Painéis")]
    public GameObject painelPositivo;
    public GameObject painelNegativo;
    public GameObject painelSemVidas; // Referência para o novo painel

    [Header("Áudio de Feedback")]
    public AudioClip somFeedbackPositivo;
    public AudioClip somFeedbackNegativo;

    [Header("UI Painel Positivo")]
    public TextMeshProUGUI textoAcertosPositivo;
    public TextMeshProUGUI textoTempoPositivo;
    public TextMeshProUGUI textoMoedasGanhaas;
    public TextMeshProUGUI textoPontosGanhos;

    [Header("UI Painel Negativo")]
    public TextMeshProUGUI textoAcertosNegativo;
    public TextMeshProUGUI textoTempoNegativo;

    [Header("UI da Barra de Navegação Superior (NavBar)")]
    public TextMeshProUGUI textoMoedasTopbar;
    public TextMeshProUGUI textoVidasTopbar;

    private string ultimaCenaJogada; // Guarda o nome da cena para recarregar

    void Start()
    {
        if (painelSemVidas != null) painelSemVidas.SetActive(false);

        if (PlayerDataManager.Instance == null || PlayerDataManager.Instance.Dados == null)
        {
            SceneManager.LoadScene("CenaLogin");
            return;
        }

        // Pega os resultados que o QuizManager passou
        ultimaCenaJogada = PlayerPrefs.GetString("UltimaCenaJogada");
        int acertos = PlayerPrefs.GetInt("AcertosFinal", 0);
        int totalPerguntas = PlayerPrefs.GetInt("TotalPerguntasFinal", 1);
        float tempoRestante = PlayerPrefs.GetFloat("TempoFinal", 0f); // Agora é o tempo RESTANTE
        string idDoNivel = PlayerPrefs.GetString("idDoNivelFinal", "nivel_desconhecido");
        string resultado = PlayerPrefs.GetString("ResultadoFinal", "derrota");
        
        // --- MODIFICAÇÃO ---
        // Pega o tempo limite que o QuizManager salvou
        float tempoLimite = PlayerPrefs.GetFloat("TempoLimiteInicial", 300f);
        // ------------------

        // Limpa os dados temporários
        PlayerPrefs.DeleteKey("AcertosFinal");
        PlayerPrefs.DeleteKey("TotalPerguntasFinal");
        PlayerPrefs.DeleteKey("TempoFinal");
        PlayerPrefs.DeleteKey("idDoNivelFinal");
        PlayerPrefs.DeleteKey("ResultadoFinal");
        PlayerPrefs.DeleteKey("TempoLimiteInicial"); // --- MODIFICAÇÃO --- (Limpa o novo PlayerPref)

        // --- MODIFICAÇÃO ---
        // Calcula o tempo GASTO para exibir no painel
        float tempoGasto = tempoLimite - tempoRestante;
        if (tempoGasto < 0f) tempoGasto = 0f; // Garante que não seja negativo
        string tempoFormatado = string.Format("{0:00}:{1:00}", (int)tempoGasto / 60, (int)tempoGasto % 60);
        // ------------------
        
        if (resultado == "vitoria")
        {
            // Lógica do painel positivo...
            painelPositivo.SetActive(true);
            painelNegativo.SetActive(false);
            if (AudioManager.Instance != null) AudioManager.Instance.PlaySFX(somFeedbackPositivo);
            textoAcertosPositivo.text = $"{acertos}/{totalPerguntas} ACERTOS";
            textoTempoPositivo.text = tempoFormatado; // Mostra o tempo gasto

            // --- FÓRMULAS DE RECOMPENSA (QUIZ) REBALANCEADAS ---

            // Moedas: Reduzidas (antes era acertos * 10)
            // Agora: 10 moedas base + 2 por acerto. (Ex: 10 acertos = 30 moedas)
            int moedasGanhaas = 10 + (acertos * 2);

            // Pontuação: Aumentada e baseada em bônus de tempo restante (antes era (acertos * 50) - (tempoFinal * 2.0f))
            // Agora: 50 pontos base + 100 por acerto + 2 pontos por segundo RESTANTE
            int bonusDeTempo = (int)(tempoRestante * 2.0f);
            int pontuacaoFinal = 50 + (acertos * 100) + bonusDeTempo;
            
            // ----------------------------------------------------

            textoMoedasGanhaas.text = moedasGanhaas.ToString() + " moedas";
            textoPontosGanhos.text = pontuacaoFinal.ToString() + " pontos";
            PlayerDataManager.Instance.Dados.Moedas += moedasGanhaas;
            PlayerDataManager.Instance.Dados.PontuacoesPorNivel.TryGetValue(idDoNivel, out long pontuacaoAntiga);
            if (pontuacaoFinal > pontuacaoAntiga)
            {
                long diferencaDePontos = pontuacaoFinal - pontuacaoAntiga;
                
                // --- MODIFICAÇÃO ---
                // Atualiza o total de PONTUAÇÃO DO QUIZ, não mais o total geral.
                PlayerDataManager.Instance.Dados.PontuacaoTotalQuiz += diferencaDePontos;
                // PlayerDataManager.Instance.Dados.PontuacaoMaximaTotal += diferencaDePontos; // Linha antiga removida
                // -------------------

                PlayerDataManager.Instance.Dados.PontuacoesPorNivel[idDoNivel] = pontuacaoFinal;
            }
        }
        else // Se resultado for "derrota"
        {
            // Lógica do painel negativo...
            painelPositivo.SetActive(false);
            painelNegativo.SetActive(true); // Corrigido de painelErrado para painelNegativo
            if (AudioManager.Instance != null) AudioManager.Instance.PlaySFX(somFeedbackNegativo);
            textoAcertosNegativo.text = $"{acertos}/{totalPerguntas} ACERTOS";
            textoTempoNegativo.text = tempoFormatado; // Mostra o tempo gasto
            PlayerDataManager.Instance.Dados.Vidas--;
            if (PlayerDataManager.Instance.Dados.Vidas < 0) PlayerDataManager.Instance.Dados.Vidas = 0;
        }

        textoMoedasTopbar.text = PlayerDataManager.Instance.Dados.Moedas.ToString();
        textoVidasTopbar.text = PlayerDataManager.Instance.Dados.Vidas.ToString();
        PlayerDataManager.Instance.SalvarDadosNoFirebase();
    }

    public void TentarNovamente()
    {
// ... (código restante sem alterações) ...
        if (PlayerDataManager.Instance.Dados.Vidas < 1)
        {
            if (painelSemVidas != null) painelSemVidas.SetActive(true);
            return;
        }

        if (!string.IsNullOrEmpty(ultimaCenaJogada))
        {
            SceneManager.LoadScene(ultimaCenaJogada);
        }
        else
        {
            Debug.LogError("Não foi possível encontrar a última cena jogada! Voltando ao menu.");
            RetornarAoMenu();
        }
    }

    public void RetornarAoMenu()
    {
        GameDataHolder.NivelParaCarregar = null;
        SceneManager.LoadScene("CenaMenu");
    }

    public void IrParaPlacar()
    {
        GameDataHolder.NivelParaCarregar = null;
        
        // --- MODIFICAÇÃO ---
        // Define a aba que deve ser aberta na cena de ranking
        RankingState.TabParaAbrir = RankingTab.Quiz;
        // -------------------

        SceneManager.LoadScene("CenaRanking");
    }

    public void FecharPainelSemVidas()
    {
        if (painelSemVidas != null)
        {
            painelSemVidas.SetActive(false);
        }
    }
}